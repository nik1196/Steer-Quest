#include <stdio.h>
#include "Simulation.h"
#include <iostream>
#pragma once

extern Vec2f endP;
extern unsigned int endR; 

extern int diag_size;
extern int diag_done;
extern int box_size;
extern int box_done;

extern int level;
extern int count;

extern vector<Vec3f> obstacles;

#define DEBUG 0


