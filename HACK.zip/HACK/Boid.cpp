#include "Boid.h"
#include "constants.h"
#include<iostream>
/*

Add functions needed to create a working flock.


*/
Boid::Boid(int x, int y, int xbound, int ybound,
        int     mboundaryPadding    ,
        float   mmaxSpeed           ,
        float   mmaxForce           ,
        float   mflockSepWeight     ,
        float   mflockAliWeight     ,
        float   mflockCohWeight     ,
        float   mflockSepRadius     ,
        float   mflockAliRadius     ,
        float   mflockCohRadius     )
{

    loc.setval(x,y);
	vel.setval(0,0);
	acc.setval(0,0);
    r = 3.0;
    orient = 0;
    endCorner.setval(xbound,ybound);
    reachedDestination = false;
    hitObstacle = false;

    boundaryPadding =   mboundaryPadding;
    maxSpeed        =   mmaxSpeed      ;  
    maxForce        =   mmaxForce      ;  
    flockSepWeight  =   mflockSepWeight;
    flockAliWeight  =   mflockAliWeight;
    flockCohWeight  =   mflockCohWeight;
    flockSepRadius  =   mflockSepRadius;
    flockAliRadius  =   mflockAliRadius;
    flockCohRadius  =   mflockCohRadius;

}

// Method to update location
void Boid::update(vector<Boid> &boids) {

	flock(boids);

    vel += acc;   // Update velocity
    vel *= maxSpeed;
    loc += vel;
    acc.setval(0,0);  // Resetval accelertion to 0 each cycle
    orient = (float)atan2(vel.y,vel.x) * 180/PI;

    boundCheck(boundaryPadding); 


}


void Boid::boundCheck(int padding) {

    if(loc.x>endCorner.x-padding)
    {
        loc.x=endCorner.x-padding;
        vel.x=-vel.x;

    }

    else if(loc.x<0+padding)
     {
         loc.x=0+padding;
         vel.x=-vel.x;
     }

    if(loc.y>endCorner.y-padding)
    {
        loc.y=endCorner.y-padding;
        vel.y=-vel.y;
    }

    else if(loc.y<0+padding)
    {
        loc.y=0+padding;
        vel.y=-vel.y;
    }


}


Vec2f Boid::separate(vector<Boid> boids)
{
    float desired=flockSepRadius;
    Vec2f st(0,0);
    int count=0;
    for(int i=0;i<boids.size();i++)
    {
        float d=dist(loc,boids[i].loc);
	cout<<d<<endl;
        if((d>0) && (d<desired))
        {
            Vec2f diff=loc-boids[i].loc;
            diff.normalize();
            diff/=d;
            st+=diff;
            count++;
        }
    }
    if(count>0)
    {
        st/=(float)count;
    }
    /*float mag= sqrt(pow(st.x,2)+ pow(st.y,2));
    if(mag>0)
    {
        st.normalize();
        st=st*maxSpeed;
        st=st-vel;
        if(sqrt(pow(st.x,2)+ pow(st.y,2))>maxForce)
        {
            st.normalise();
            st*=maxForce;
        }
    }*/
    return st;


}

Vec2f Boid::align(vector<Boid> boids)
{
    float desired=flockAliRadius;
    Vec2f st(0,0),sd(0,0);
    int count=0;
    for(int i=0;i<boids.size();i++)
    {
        float d=dist(loc,boids[i].loc);
        if((d>0) && (d<desired))
        {
            st+=boids[i].vel;
		sd+=boids[i].loc;
            count++;
        }
    }
    if(count>0)
    {
        st/=(float)count;
	sd/=(float)count;
    }
	st+=(endP-sd)*flockAliWeight;
	for (int i=0;i<boids.size();i++)
	{
		boids[i].vel.x+=(st.x);
		boids[i].vel.y+=(st.y);
	}

    float mag= sqrt(pow(st.x,2)+ pow(st.y,2));

       
        /*  st=st*maxSpeed;
        Vec2f sum=st-vel;
        if(sqrt(pow(sum.x,2)+ pow(sum.y,2))>maxForce)
        {
            sum.normalise();
            sum*=maxForce;
            return sum;
        }
        else
        {
            sum.x=sum.y=0;
        }*/
        return st;

}
Vec2f Boid::seek(Vec2f st)
{
    Vec2f desired=st-loc;
    desired.normalize();
    /*desired*=maxSpeed;*/
    Vec2f sum;
    float mag=sqrt(pow(desired.x,2)+ pow(desired.y,2));
    if(mag>0)
        {
            desired.normalize();

            if(mag<=maxForce)
            {
                desired*=(maxSpeed*mag/maxForce);
            }
            else
                desired*=maxSpeed;
            sum=desired-vel;

        }
        else
            sum.x=sum.y=0;
        return sum;
}



Vec2f Boid::cohesion(vector<Boid> boids)
{
    float desired=flockCohRadius;
    Vec2f st(0,0);
    int count=0;
    for(int i=0;i<boids.size();i++)
    {
        float d=dist(loc,boids[i].loc);
        if((d>0) && (d>desired))
        {
            st+=boids[i].loc;
            count++;
        }
    }
    if(count>0)
    {
        st/=(float)count;
        return seek(st);
    }
    else{
            st.x=st.y=0;
            return st;
    }
}
void Boid::flock(vector<Boid> &boids) {
    Vec2f sep= separate(boids);
    Vec2f ali= align(boids);
    Vec2f coh= cohesion(boids);
	cout<<coh.x<<" "<<coh.y<<endl;

    sep*=flockSepWeight;
   //ali*=flockAliWeight;
	
    coh*=flockCohWeight;
    acc+=(endP-loc)*0.1+(sep+coh);

}

bool Boid::isHit(int x, int y, int radius) {
    
    int range = 1;//calculation error range
    int dist =radius + range;
    if(pow((x-loc.x),2)+pow((y-loc.y),2) < (dist * dist) ){
        return true;
    }
    return false;
}


float Boid::dist(Vec2f v1,Vec2f v2)
{
    return v1.distance(v2);
}

float Boid::clamp(float val, float minval, float maxval)
{
    if(val<minval)
        return minval;
    else if (val>maxval)
        return maxval;
    else
        return val;
}
